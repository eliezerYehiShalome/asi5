package org.example;

public class Main {
    public static void main(String[] args) {
        window window=new window();
        System.out.println("Hello world!");

    }
}